package com.example.brownspotapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
