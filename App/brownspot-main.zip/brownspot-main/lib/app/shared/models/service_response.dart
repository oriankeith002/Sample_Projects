class ServiceResponse {
  bool success;
  String message;
  dynamic data;

  ServiceResponse({
    this.success,
    this.message,
    this.data,
  });
}
