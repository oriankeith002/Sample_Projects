import 'package:brownspotapp/app/shared/global_variables.dart';

String getCodeGivenDiseaseLabel(String diseaseLabel) {
  return diseaseLabelToCode[diseaseLabel];
}
