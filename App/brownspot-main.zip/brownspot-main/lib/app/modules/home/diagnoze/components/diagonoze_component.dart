import 'package:brownspotapp/app/shared/components/custom_button.dart';
import 'package:brownspotapp/app/shared/global_variables.dart';
import 'package:brownspotapp/color_resources.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:flutter_modular/flutter_modular.dart';

import '../../home_controller.dart';

class DiagonozeComponent extends StatefulWidget {
  @override
  _DiagonozeComponentState createState() => _DiagonozeComponentState();
}

class _DiagonozeComponentState
    extends ModularState<DiagonozeComponent, HomeController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: Observer(
        builder: (context) {
          if (controller.imagesStore.error != null) {
            print(
                "????????????!!!!!! ${controller.imagesStore.error}");
          }
          return Center(
            child: Column(
              children: [
                 Padding(
                          padding: const EdgeInsets.all(8.0),
                          child:Image.asset('assets/images/empty.png')),
                Text('No Diagonisis found \nKindly upload or take a picture of the leaf.',textAlign: TextAlign.center,style: TextStyle(
                              color: ColorResources.getblackColor(context).withOpacity(.5),
                              fontFamily: fontFamily,
                              fontSize: 14.0,
                            ),),
              ],
            ),
             );
        },
      ),
      floatingActionButton: CustomButton(
              isActive: true,
              isBusy: controller.busy,
              title: "Add Photo",
              onPressed: () => showModalBottomSheet(
                context: context,
                builder: (BuildContext context) => Container(
                  padding: const EdgeInsets.symmetric(
                      vertical: 20.0, horizontal: 8.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomButtonWithoutColor(
                        borderColor: ColorResources.getPrimaryColor(context),
                        title: "Camera",
                        onPressed: () async {
                          Navigator.pop(context);
                          await controller.getImage(ImageFrom.Camera);
                        },
                      ),
                      SizedBox(height: 10.0),
                      CustomButtonWithoutColor(
                        borderColor: ColorResources.getPrimaryColor(context),
                        title: "Gallery",
                        onPressed: () async {
                          Navigator.pop(context);
                          await controller.getImage(ImageFrom.Gallery);
                        },
                      ),
                      SizedBox(height: 10.0),
                    ],
                  ),
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(cardBorderRadius),
                    topRight: Radius.circular(cardBorderRadius),
                  ),
                ),
              ),
            ),
         
    );
  }
}
