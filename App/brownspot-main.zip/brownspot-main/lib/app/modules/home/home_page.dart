import 'package:brownspotapp/color_resources.dart';
import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:brownspotapp/app/modules/home/diagnoze/components/diagonoze_component.dart';
import 'package:brownspotapp/app/modules/home/home_controller.dart';
import 'package:brownspotapp/app/modules/home/results/components/results_component.dart';

class HomePage extends StatefulWidget {
  final int selectedIndex;

  const HomePage({Key key, this.selectedIndex = 0})
      : assert(selectedIndex != null),
        super(key: key);
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _homeController = Modular.get<HomeController>();
  int _currentIndex;

  @override
  void initState() {
    super.initState();
    _homeController.imagesStore.loadModel();
    _currentIndex = widget.selectedIndex;
  }

  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    //   body: IndexedStack(
    //     index: _currentIndex,
    //     children: [DiagonozeComponent(), ResultsComponent()],
    //   ),
    //   bottomNavigationBar: BottomNavigationBar(
    //     currentIndex: _currentIndex,
    //     selectedItemColor: ColorResources.getPrimaryColor(context),
    //     items: [
    //       BottomNavigationBarItem(
    //         icon: Icon(Icons.play_arrow),
    //         label: "Diagnoze",
    //       ),
    //       BottomNavigationBarItem(
    //         icon: Icon(Icons.history),
    //         label: "Results",
    //       ),
    //     ],
    //     onTap: (int index) {
    //       setState(() {
    //         _currentIndex = index;
    //       });
    //     },
    //   ),
    // );
    return DefaultTabController(
      length: 2,
      initialIndex: _currentIndex,
      child: Scaffold(
          body: NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            new SliverAppBar(
              title: Text('Brownspot App',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white)),
              pinned: true,
              backgroundColor: ColorResources.getPrimaryColor(context),
              floating: true,
              centerTitle: true,
              bottom: TabBar(
                isScrollable: true,
                tabs: [
                  Padding(
                    padding: const EdgeInsets.only(right: 50.0),
                    child: Tab(
                        child: Text('Diagonize',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.white))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 50.0),
                    child: Tab(
                        child: Text('Results',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.white))),
                  ),
                ],
              ),
            ),
          ];
        },
        body: TabBarView(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 12),
              child: DiagonozeComponent(),
            ),
            Padding(
              padding: EdgeInsets.only(top: 12),
              child: ResultsComponent(),
            ),
          ],
        ),
      )),
    );
  }
}
