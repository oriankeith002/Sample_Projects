import 'package:brownspotapp/app/shared/global_variables.dart';
import 'package:brownspotapp/app/shared/models/service_response.dart';

abstract class IImagePickerService {
  Future<ServiceResponse> getImage(ImageFrom imageFrom);
}
