import 'dart:io';

import 'package:brownspotapp/app/shared/models/service_response.dart';

abstract class ITensorflowService {
  Future<ServiceResponse> loadModel();
  Future<ServiceResponse> classifyImage(File image);
}
