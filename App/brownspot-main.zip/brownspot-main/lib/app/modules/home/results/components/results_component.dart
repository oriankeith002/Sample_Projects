import 'package:brownspotapp/app/shared/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:brownspotapp/app/modules/home/results/results_controller.dart';

import '../../../../../color_resources.dart';

class ResultsComponent extends StatefulWidget {
  @override
  _ResultsComponentState createState() => _ResultsComponentState();
}

class _ResultsComponentState
    extends ModularState<ResultsComponent, ResultsController> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 2,
            child: controller.imagesStore.selectedImage != null
                ? Image.file(
                    controller.imagesStore.selectedImage,
                    fit: BoxFit.cover,
                  )
                : Container(),
          ),
          // Expanded(
          //   flex: 3,
          //   child:
          //        Center(
          //           child: Column(
          //             children: [
          //                Padding(
          //                 padding: const EdgeInsets.all(8.0),
          //                 child:Image.asset('assets/images/empty.png')),
          //               Padding(
          //                 padding: const EdgeInsets.all(8.0),
          //                 child: Text(
          //                   "No results Found.\n Diagnoze to receive a result.",
          //                   textAlign: TextAlign.center,
          //                   style: TextStyle(
          //                     color: ColorResources.getblackColor(context).withOpacity(.5),
          //                     fontFamily: 'poppins',
          //                     fontSize: 14.0,
          //                   ),
          //                 ),
          //               ),
          //             ],
          //           ),
          //         )

          // ),
          Expanded(
            flex: 3,
            child: controller.imagesStore.result == null
                ? Center(
                    child: Column(
                    children: [
                      Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset('assets/images/empty.png')),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "No results Found.\n Diagnoze to receive a result.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: ColorResources.getblackColor(context)
                                .withOpacity(.5),
                            fontFamily: 'poppins',
                            fontSize: 14.0,
                          ),
                        ),
                      ),
                    ],
                  ))
                : Container(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: Text('Detected Disease',
                                  maxLines: 3,
                                  softWrap: true,
                                  overflow: TextOverflow.fade,
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: ColorResources.getHintColor(
                                          context))),
                            ),
                            Flexible(
                              child: Text(
                                  controller.imagesStore.result.label
                                      .split(" ")
                                      .last,
                                  maxLines: 3,
                                  softWrap: true,
                                  overflow: TextOverflow.fade,
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: ColorResources.getHintColor(
                                          context))),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: Text('Accuracy',
                                  maxLines: 3,
                                  softWrap: true,
                                  overflow: TextOverflow.fade,
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: ColorResources.getHintColor(
                                          context))),
                            ),
                            Flexible(
                              child: Text(
                                  '${(controller.imagesStore.result.confidence * 100).toStringAsFixed(3)} %',
                                  maxLines: 3,
                                  softWrap: true,
                                  overflow: TextOverflow.fade,
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: ColorResources.getHintColor(
                                          context))),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
